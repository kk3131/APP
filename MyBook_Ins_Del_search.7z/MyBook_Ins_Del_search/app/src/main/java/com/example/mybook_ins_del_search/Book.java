package com.example.mybook_ins_del_search;

public class Book {
    private String name;
    private String number;

    public Book(String name, String number) {//建構方法
        this.name = name;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}